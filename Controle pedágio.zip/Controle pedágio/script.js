const DISTANCIA = 120; // km
const VALOR_PEDAGIO = 20.0; // reais

let veiculos = [];
let inicioProcesso = null;
let finalProcesso = null;

function parseHora(horaStr) {
  const [h, m] = horaStr.split(":").map(Number);
  return h + m / 60;
}

function calcularTempo(horaEntrada, horaSaida) {
  return parseHora(horaSaida) - parseHora(horaEntrada);
}

function calcularVelocidade(tempo) {
  return DISTANCIA / tempo;
}

function calcularDesconto(velocidade) {
  if (velocidade <= 60) return 0.15;
  if (velocidade <= 100) return 0.10;
  return 0;
}

function calcularValor(velocidade) {
  const desconto = calcularDesconto(velocidade);
  return VALOR_PEDAGIO * (1 - desconto);
}

function horaFormatada(horaDecimal) {
  const h = Math.floor(horaDecimal);
  const m = Math.round((horaDecimal - h) * 60);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function mostrarTicket(veiculo) {
  const ticketDiv = document.getElementById("ticket");
  ticketDiv.style.display = "block";
  ticketDiv.textContent = `
--- Ticket de Cobrança ---
Placa do veículo: ${veiculo.placa}
Hora de entrada: ${veiculo.horaEntrada}
Hora de saída: ${veiculo.horaSaida}
Tempo gasto (h): ${veiculo.tempo}
Velocidade média: ${veiculo.velocidade} km/h
Valor pago: R$ ${veiculo.valorPago}
-------------------------
  `;
}

function registrarVeiculo(placa, horaEntrada, horaSaida) {
  const tempo = calcularTempo(horaEntrada, horaSaida);
  if (tempo <= 0) {
    alert("Hora de saída deve ser maior que a hora de entrada.");
    return false;
  }

  const velocidade = calcularVelocidade(tempo);
  const valorPago = calcularValor(velocidade);

  const veiculo = {
    placa,
    horaEntrada,
    horaSaida,
    tempo: tempo.toFixed(2),
    velocidade: velocidade.toFixed(2),
    valorPago: valorPago.toFixed(2),
  };

  veiculos.push(veiculo);

  const entradaNumerica = parseHora(horaEntrada);
  const saidaNumerica = parseHora(horaSaida);

  if (!inicioProcesso || entradaNumerica < inicioProcesso) {
    inicioProcesso = entradaNumerica;
  }
  if (!finalProcesso || saidaNumerica > finalProcesso) {
    finalProcesso = saidaNumerica;
  }

  mostrarTicket(veiculo);
  return true;
}

function fecharCaixa() {
  if (veiculos.length === 0) {
    alert("Nenhum veículo registrado.");
    return;
  }

  const velocidades = veiculos.map(v => parseFloat(v.velocidade));
  const valores = veiculos.map(v => parseFloat(v.valorPago));

  const menorVelocidade = Math.min(...velocidades).toFixed(2);
  const maiorVelocidade = Math.max(...velocidades).toFixed(2);
  const mediaVelocidade = (velocidades.reduce((a, b) => a + b, 0) / velocidades.length).toFixed(2);
  const totalValores = valores.reduce((a, b) => a + b, 0).toFixed(2);

  const relatorioDiv = document.getElementById("relatorio");
  relatorioDiv.style.display = "block";
  relatorioDiv.textContent = `
===== RELATÓRIO FINAL DO TURNO =====
Menor velocidade registrada: ${menorVelocidade} km/h
Maior velocidade registrada: ${maiorVelocidade} km/h
Média das velocidades: ${mediaVelocidade} km/h
Total arrecadado: R$ ${totalValores}
Hora de início do processamento: ${horaFormatada(inicioProcesso)}
Hora de final do processamento: ${horaFormatada(finalProcesso)}
====================================
  `;
}

// Eventos
document.getElementById("formVeiculo").addEventListener("submit", e => {
  e.preventDefault();

  const placa = e.target.placa.value.toUpperCase();
  const horaEntrada = e.target.horaEntrada.value;
  const horaSaida = e.target.horaSaida.value;

  const sucesso = registrarVeiculo(placa, horaEntrada, horaSaida);
  if (sucesso) {
    e.target.reset();
  }
});

document.getElementById("btnFecharCaixa").addEventListener("click", () => {
  fecharCaixa();
});
